Sistema de Pedidos de uma Lanchonete
O objetivo do sistema da lanchonete é facilitar o gerenciamento de pedidos, produtos e usuários. 
Ele permite que os administradores controlem tudo, como cadastrar produtos, gerenciar estoque e criar promoções, 
enquanto os usuários comuns podem fazer pedidos e avaliar produtos. O sistema organiza tudo de forma prática, ajudando na administração 
e oferecendo uma boa experiência de compra.

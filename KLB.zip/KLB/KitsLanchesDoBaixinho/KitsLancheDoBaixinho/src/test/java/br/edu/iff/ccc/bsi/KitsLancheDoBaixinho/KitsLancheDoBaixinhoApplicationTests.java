package br.edu.iff.ccc.bsi.KitsLancheDoBaixinho;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class KitsLancheDoBaixinhoApplicationTests {

	@Test
	void contextLoads() {
	}

}

package br.edu.iff.ccc.bsi.KitsLancheDoBaixinho.Entities;

enum tipoProduto {
    LANCHE,
    BEBIDA,
    SOBREMESA
}

public class Produto {

    private int id;
    private String nome;
    private double preco;
    private tipoProduto tipo;

    public Produto(int id, String nome, double preco, tipoProduto tipo) {
        this.id = id;
        this.nome = nome;
        this.preco = preco;
        this.tipo = tipo;
    }

    public int getId() {
        return id;
    }

    public String getNome() {
        return nome;
    }

    public double getPreco() {
        return preco;
    }

    public tipoProduto getTipo() {
        return tipo;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public void setPreco(double preco) {
        this.preco = preco;
    }

    public void setType(tipoProduto tipo) {
        this.tipo = tipo;
    }

}

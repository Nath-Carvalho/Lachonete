package br.edu.iff.ccc.bsi.KitsLancheDoBaixinho.Entities;

public class Pedido {

    private int id;
    private User user;
    private Produto produto;
    private String observacao;
    private Produto acrescimos;
    private double precoTotal;
    
    public Pedido(int id, User user, Produto produto, String observacao, Produto acrescimos, double precoTotal) {
        this.id = id;
        this.user = user;
        this.produto = produto;
        this.observacao = observacao;
        this.acrescimos = acrescimos;
        this.precoTotal = precoTotal;
    }
    
    public int getId() {
        return id;
    }
    public User getUser() {
        return user;
    }
    public Produto getProduto() {
        return produto;
    }
    public String getObservacao() {
        return observacao;
    }
    public Produto getAcrescimos() {
        return acrescimos;
    }
    public double getPrecoTotal() {
        return precoTotal;
    }


    public void setId(int id) {
        this.id = id;
    }
    public void setUser(User user) {
        this.user = user;
    }
    public void setProduto(Produto produto) {
        this.produto = produto;
    }
    public void setObservacao(String observacao) {
        this.observacao = observacao;
    }
    public void setAcrescimos(Produto acrescimos) {
        this.acrescimos = acrescimos;
    }
    public void setPrecoTotal(double precoTotal) {
        this.precoTotal = precoTotal;
    }

}

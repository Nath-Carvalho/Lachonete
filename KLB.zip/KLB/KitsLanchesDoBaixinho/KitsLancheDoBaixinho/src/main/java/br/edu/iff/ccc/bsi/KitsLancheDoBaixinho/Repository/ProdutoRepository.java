package br.edu.iff.ccc.bsi.KitsLancheDoBaixinho.Repository;

public class ProdutoRepository {

}

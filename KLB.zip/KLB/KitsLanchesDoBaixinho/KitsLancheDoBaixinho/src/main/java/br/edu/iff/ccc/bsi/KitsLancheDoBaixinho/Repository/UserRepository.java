package br.edu.iff.ccc.bsi.KitsLancheDoBaixinho.Repository;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
//import org.springframework.data.jpa.repository.JpaRepository;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import br.edu.iff.ccc.bsi.KitsLancheDoBaixinho.Entities.User;

@Repository
public class UserRepository {
    private List<User> users = new ArrayList<>();
    private int nextId = 1;

    public void addUser(User user) {
        if (user == null) {
            throw new IllegalArgumentException("Usuário não pode ser nulo");
        }
        user.setId(nextId++);
        users.add(user);
    }

    public Optional<User> getUserById(int id) {
        if (id <= 0) {
            throw new IllegalArgumentException("ID deve ser maior que zero");
        }
        return users.stream().filter(user -> user.getId() == id).findFirst();
    }

    public List<User> getAllUsers() {
        return new ArrayList<>(users);
    }

    public void updateUser(User user) {
        if (user == null) {
            throw new IllegalArgumentException("Usuário não pode ser nulo");
        }
        getUserById(user.getId()).ifPresentOrElse(existingUser -> {
            users.remove(existingUser);
            users.add(user);
        }, () -> {
            throw new IllegalArgumentException("Usuário com ID " + user.getId() + " não existe");
        });
    }

    public void deleteUser(int id) {
        if (id <= 0) {
            throw new IllegalArgumentException("ID deve ser maior que zero");
        }
        getUserById(id).ifPresentOrElse(users::remove, () -> {
            throw new IllegalArgumentException("Usuário com ID " + id + " não existe");
        });
    }

    @Query(value = "SELECT * FROM users WHERE email = :email OR username = :username", nativeQuery = true)
    Optional<User> findByEmailOrUsername(@Param("email") String email, @Param("username") String username);
}

    @Query(value = "SELECT * FROM users WHERE username = :username", nativeQuery = true)
     Optional<User> findByUsername(@Param("username") String username);

     
}


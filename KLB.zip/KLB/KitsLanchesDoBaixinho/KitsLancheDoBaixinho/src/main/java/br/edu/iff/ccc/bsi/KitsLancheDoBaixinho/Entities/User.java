package br.edu.iff.ccc.bsi.KitsLancheDoBaixinho.Entities;

enum tipoUser {
    ADMIN,
    CLIENT
}

public class User {

    private int id;
    private String nome;
    private String email;
    private String senha;
    private tipoUser tipo;

    public User(int id, String nome, String email, String senha, tipoUser tipo) {
        this.id = id;
        this.nome = nome;
        this.email = email;
        this.senha = senha;
        this.tipo = tipo;
    }

    public int getId() {
        return id;
    }

    public String getNome() {
        return nome;
    }

    public String getEmail() {
        return email;
    }

    public String getSenha() {
        return senha;
    }

    public tipoUser getTipo() {
        return tipo;
    }


    public void setId(int id) {
        this.id = id;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void setSenha(String senha) {
        this.senha = senha;
    }

    public void setType(tipoUser tipo) {
        this.tipo = tipo;
    }

    @Override
    public String toString() {
        return "User{" +
                "id='" + id + '\'' +
                "nome='" + nome + '\'' +
                ", email='" + email + '\'' +
                ", senha='" + senha + '\'' +
                ", tipo=" + tipo +
                '}';
    }

}


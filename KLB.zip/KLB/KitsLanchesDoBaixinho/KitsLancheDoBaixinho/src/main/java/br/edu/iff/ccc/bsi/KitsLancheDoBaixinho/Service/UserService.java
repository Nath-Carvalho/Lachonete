package br.edu.iff.ccc.bsi.KitsLancheDoBaixinho.Service;

import java.util.List;

import org.springframework.stereotype.Service;
import br.edu.iff.ccc.bsi.KitsLancheDoBaixinho.Entities.User;
import br.edu.iff.ccc.bsi.KitsLancheDoBaixinho.Repository.UserRepository;
import java.util.Optional;

@Service
public class UserService {

    private final UserRepository userRepository;

    public UserService(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    public User createUser(User user) {
        if (user == null) {
            throw new IllegalArgumentException("Email não pode ser nulo ou vazio");
        }
        if (getUserByEmail(user.getEmail()).isPresent()) {
            throw new IllegalArgumentException("Email já está em uso");
        }
        userRepository.addUser(user);
        return user;
    }

    public Optional<User> getUserByEmail(String email) {
        if (email == null || email.isEmpty()) {
            throw new IllegalArgumentException("Email não pode ser nulo ou vazio");
        }
        List<User> users = userRepository.getAllUsers();
        try {
            return users.stream()
                    .filter(u -> email.equals(u.getEmail()))
                    .findFirst();
        } catch (Exception e) {
            throw new RuntimeException("Um erro ocorreu enquanto buscava o email", e);
        }
    }

    public List<User> getAllUsers() {
        try {
            if (userRepository.getAllUsers().isEmpty()) {
                throw new IllegalArgumentException("Nenhum usuario encontrado");
            }
            return userRepository.getAllUsers();
        } catch (Exception e) {
            throw new RuntimeException("Um erro ocorreu enquanto buscava os usuarios", e);
        }
    }

    public Optional<User> getUserById(Integer id) {
        if (id == null) {
            throw new IllegalArgumentException("ID não pode ser null");
        }
        Optional<User> u  = userRepository.getUserById(id);
        if (u != null) {
            return u;
        }
        throw new IllegalArgumentException("Usuario nao encontrado");
    }

    public User updateUser(Integer id, User user) {
        if (id == null || user == null) {
            throw new IllegalArgumentException("ID e usuario não pode ser null");
        }
        Optional<User> existingUser = userRepository.getUserById(id);
        if (!existingUser.isPresent()) {
            throw new IllegalArgumentException("Usuario nao encontrado");
        }
        user.setId(id);
        userRepository.updateUser(user);
        return user;
    }

    public void deleteUser(Integer id) {
        if (id == null) {
            throw new IllegalArgumentException("ID nao pode ser null");
        }

        User d_user = userRepository.getUserById(id).get();
        if (d_user == null) {
            throw new IllegalArgumentException("Usuario nao encontrado");    
        }
        userRepository.deleteUser(id);
    }
}

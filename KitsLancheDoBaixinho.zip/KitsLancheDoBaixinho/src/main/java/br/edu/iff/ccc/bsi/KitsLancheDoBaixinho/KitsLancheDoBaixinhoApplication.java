package br.edu.iff.ccc.bsi.KitsLancheDoBaixinho;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class KitsLancheDoBaixinhoApplication {

	public static void main(String[] args) {
		SpringApplication.run(KitsLancheDoBaixinhoApplication.class, args);
	}

}

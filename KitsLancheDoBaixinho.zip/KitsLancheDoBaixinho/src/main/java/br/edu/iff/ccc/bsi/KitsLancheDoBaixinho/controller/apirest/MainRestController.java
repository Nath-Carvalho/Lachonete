package br.edu.iff.ccc.bsi.KitsLancheDoBaixinho.controller.apirest;

import java.util.ArrayList;
import java.util.List;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.parameters.RequestBody;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;


@RestController
@RequestMapping("/api/v1/users")
@Tag(name = "UserRest", description = "Rest Controller da Lanchonete")
public class MainRestController {
    
    private List<User> users = new ArrayList<>();
    
    public MainRestController() {
        users.add(new User(1, "Nathalia", "nathalia@email.com", "1234"));
        users.add(new User(2, "Julia", "julia@email.com", "5678"));
    }

    @Operation(summary = "Cria um novo usuário")
    @ApiResponses({
        @ApiResponse(responseCode = "201", description = "Usuário criado com sucesso"),
        @ApiResponse(responseCode = "400", description = "Requisição inválida")
    })
    @PostMapping
    public ResponseEntity<User> criarUsuario(@RequestBody User user) {
        if (user.getNome() == null || user.getEmail() == null || user.getSenha() == null) {
            return ResponseEntity.badRequest().body(null);
        }

        int novoId = users.isEmpty() ? 1 : users.get(users.size() - 1).getId() + 1;
        user.setId(novoId);

        users.add(user);
        return ResponseEntity.status(201).body(user);
    }


    @Operation(summary = "Retorna todos os usuários armazenados")
    @ApiResponses({
        @ApiResponse(responseCode = "200")
    })
    @GetMapping
    public ResponseEntity<List<User>> getUsers() {
        return ResponseEntity.ok(users);
    }

    @Operation(summary = "Atualiza um usuário pelo ID")
    @ApiResponses({
        @ApiResponse(responseCode = "200", description = "Usuário atualizado com sucesso"),
        @ApiResponse(responseCode = "404", description = "Usuário não encontrado")
    })
    @PutMapping("/{id}")
    public ResponseEntity<User> atualizarUsuario(@PathVariable int id, @RequestBody User userAtualizado) {
        for (User user : users) {
            if (user.getId() == id) {
                user.setNome(userAtualizado.getNome());
                user.setEmail(userAtualizado.getEmail());
                user.setSenha(userAtualizado.getSenha());
                return ResponseEntity.ok(user);
            }
        }
        return ResponseEntity.notFound().build();
    }

    @Operation(summary = "Deleta um usuário pelo ID")
    @ApiResponses({
        @ApiResponse(responseCode = "200", description = "Usuário deletado com sucesso"),
        @ApiResponse(responseCode = "404", description = "Usuário não encontrado")
    })
    @DeleteMapping("/{id}")
    public ResponseEntity<String> deletarUsuario(@PathVariable int id) {
        for (User user : users) {
            if (user.getId() == id) {
                users.remove(user);
                return ResponseEntity.ok("Usuário removido com sucesso");
            }
        }
        return ResponseEntity.notFound().build();
    }
}


